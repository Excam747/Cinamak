# Cinamak for Android

Cinamak is a personal Android media browser with an Arabic/English interface. It queries Internet Archive for real items published under public-domain or open-license terms, displays available metadata and cover images, checks the item's files, and plays a selected compatible video inside the app using Android's built-in `VideoView` player.

## What works in this project
- Arabic/English interface toggle.
- Live catalog search, category filters, refresh, and pagination.
- Real cover images and metadata from Internet Archive.
- Persistent favorites stored on the device.
- Checks for available MP4/WebM video files before offering playback.
- In-app playback controls. If an item offers multiple video files, the user can choose the file; a resolution label is shown when the filename contains one.

## Honest limitations
- This is **not** a mirror of Egybest and does not include unauthorized copyrighted streams.
- The available catalog is whatever Internet Archive currently indexes and licenses openly. It will not contain every current movie, TV series, anime, or cartoon.
- Not every catalog result contains a playable file, and not every file offers multiple resolutions. Quality options depend on the files actually provided by the publisher.
- Video support depends on Android's media codecs; some WebM files may not play on every device.
- The project has not been device-tested in this environment. Build the APK and test it on your phone before relying on it.

## Build an installable APK for your phone

### Easiest: GitHub Actions (free)
1. Create a new repository on GitHub and upload the **contents** of this `Cinamak` folder.
2. Open the repository's **Actions** tab and enable workflows if GitHub asks.
3. Select **Build Android APK** and press **Run workflow**. Alternatively, pushing to the `main` branch triggers it.
4. When the workflow completes, open its run and download the `cinamak-debug-apk` artifact.
5. Extract `app-debug.apk`, transfer it to your Android phone, and open it. If Android asks, allow installing apps from that file manager/browser.

The workflow uses JDK 17, Android SDK and Gradle 8.9. No paid service or Play Store publication is required.

## Network and privacy
The app requires internet access to search the catalog and stream media. Favorites are stored locally in the app's private preferences. Catalog queries go to `archive.org`; the app does not need an account.
