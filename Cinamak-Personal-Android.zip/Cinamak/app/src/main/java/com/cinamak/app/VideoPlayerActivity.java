package com.cinamak.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.MediaController;
import android.widget.TextView;
import android.widget.VideoView;
import android.net.Uri;

/** Built-in Android video player. Quality selection is done by choosing among available source files. */
public class VideoPlayerActivity extends Activity {
    private VideoView video;
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        String url = getIntent().getStringExtra("url");
        String title = getIntent().getStringExtra("title");
        boolean english = getIntent().getBooleanExtra("english", false);
        FrameLayout frame = new FrameLayout(this);
        frame.setBackgroundColor(Color.BLACK);
        video = new VideoView(this);
        frame.addView(video, new FrameLayout.LayoutParams(-1, -1));
        setContentView(frame);
        TextView label = new TextView(this);
        label.setText(title == null ? "Cinamak" : title);
        label.setTextColor(Color.WHITE);
        label.setTextSize(14);
        label.setMaxLines(2);
        label.setPadding(24, 18, 24, 18);
        label.setBackgroundColor(0x99000000);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-1, -2, Gravity.TOP);
        frame.addView(label, lp);
        MediaController controls = new MediaController(this);
        controls.setAnchorView(video);
        video.setMediaController(controls);
        video.setVideoURI(Uri.parse(url));
        video.setOnErrorListener((mp, what, extra) -> {
            label.setText(english ? "Playback failed. This file may be unavailable or unsupported." : "تعذر تشغيل الفيديو. قد يكون الملف غير متاح أو غير مدعوم.");
            return false;
        });
        video.setOnPreparedListener(mp -> video.start());
    }
    @Override protected void onPause() { super.onPause(); if (video != null && video.isPlaying()) video.pause(); }
    @Override protected void onDestroy() { if (video != null) video.stopPlayback(); getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); super.onDestroy(); }
}
